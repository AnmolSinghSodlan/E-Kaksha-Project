from django.contrib import admin
from . models import UserProfile, TeacherProfile, Subject, Note, Doubt, StudentProfile, Feedback


admin.site.register(UserProfile)
admin.site.register(TeacherProfile)
admin.site.register(Subject)
admin.site.register(Note)
admin.site.register(Doubt)
admin.site.register(StudentProfile)
admin.site.register(Feedback)

