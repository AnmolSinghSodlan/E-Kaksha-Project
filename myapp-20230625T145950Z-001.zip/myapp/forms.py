from django import forms
from .models import Note, Doubt, Solution, Feedback

class NoteForm(forms.ModelForm):
    class Meta:
        model = Note
        fields = ['subject', 'title', 'description', 'content', 'youtube', 'file']
        exclude = ("subject",)

    # def __init__(self, *args, **kwargs):
    #     super(NoteForm, self).__init__(*args, **kwargs)
        #self.fields['subject'].disabled = True
        # self.fields['subject'].widget = forms.HiddenInput()



class DoubtForm(forms.ModelForm):
    class Meta:
        model = Doubt
        fields = ['note','title', 'description', 'content', 'youtube', 'file']
        exclude = ("note","student",)


class SolutionForm(forms.ModelForm):
    class Meta:
        model = Solution
        fields = ['doubt','title', 'description', 'content', 'youtube', 'file']
        exclude = ("doubt",)

class FeedbackForm(forms.ModelForm):
    class Meta:
        model = Feedback
        fields = ['teacher_profile', 'student_profile', 'title', 'description', 'rating']
        exclude = ("student_profile",)

