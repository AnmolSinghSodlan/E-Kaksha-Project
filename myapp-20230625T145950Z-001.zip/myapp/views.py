from django.shortcuts import render, redirect


from django.contrib.auth import authenticate, login, logout


from .models import Subject, Note, UserProfile, TeacherProfile, Doubt, Solution, StudentProfile, Feedback
from .forms import NoteForm, SolutionForm, SolutionForm, DoubtForm, FeedbackForm




def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')  # Replace 'home' with the name of your home page URL pattern
        else:
            error_message = 'Invalid username or password'
    else:
        error_message = ''
    return render(request, 'login.html', {'error_message': error_message})




def logout_view(request):
    logout(request)
    return redirect('login')


def home_view(request):
    if request.user.id is None:
        return redirect('login')
    
    userProfile = UserProfile.objects.get(user=request.user)

    if userProfile.user_type == "teacher":
       
        teacherProfile = TeacherProfile.objects.get(user_profile=userProfile)
        print(teacherProfile)
        subs = Subject.objects.filter(teacher=teacherProfile).all()

        for sub in subs:
            sub.note_cnt = Note.objects.filter(subject=sub).count
    
        return render(request, 'home.html', context={'fullname': request.user.get_full_name(),'usertype': userProfile.user_type, 'subs':subs})

    else:
        print("student")

        studentProfile = StudentProfile.objects.get(user_profile=userProfile)


        subjects = studentProfile.subjects.all()
        print(subjects)

        for sub in subjects:
            sub.note_cnt = Note.objects.filter(subject=sub).count
    
    return render(request, 'students-home.html', context={'fullname': request.user.get_full_name(),'usertype': userProfile.user_type, 'subjects': subjects})








def addnote_view(request, subid):
    if request.user.id is None:
        return redirect('login')
    
    userProfile = UserProfile.objects.get(user=request.user)

    if userProfile.user_type == "teacher":
        if request.method == 'POST':
            form = NoteForm(request.POST, request.FILES)
            if form.is_valid():
                sub = Subject.objects.get(id=subid)
                form = form.save(commit=False)
                form.subject = sub
                form.save()
                print("saved")
                return redirect('home')  # Redirect to the list of notes
        else:
        
            form = NoteForm()
            
        
        return render(request, 'create_note.html', context={'fullname': request.user.get_full_name(),'usertype': userProfile.user_type, 'form': form})
    
    else:
        return redirect('home')
    


def notes_view(request, subid):

    if request.user.id is None:
        return redirect('login')
    
    userProfile = UserProfile.objects.get(user=request.user)


    if userProfile.user_type == "teacher":
        
        notes = Note.objects.filter(subject__id = subid).all()

        for note in notes:
            note.doubtscnt = Doubt.objects.filter(note=note).count
            print(note.youtube)
            print(note.file)

    
        return render(request, 'notes.html', context={'fullname': request.user.get_full_name(),'usertype': userProfile.user_type, 'notes':notes})
    else:
        notes = Note.objects.filter(subject__id = subid).all()

        studentprofile = StudentProfile.objects.get(user_profile = userProfile)

        for note in notes:
            note.doubtscnt = Doubt.objects.filter(note=note, student= studentprofile ).count
            print(note.youtube)
            print(note.file)

    
        return render(request, 'students-notes.html', context={'fullname': request.user.get_full_name(),'usertype': userProfile.user_type, 'notes':notes})






def doubts_view(request, noteid):

    if request.user.id is None:
        return redirect('login')
    
    userProfile = UserProfile.objects.get(user=request.user)
    if userProfile.user_type == "teacher":
       
        
        doubts = Doubt.objects.filter(note__id=noteid)

        for doubt in doubts:
            doubt.sol_count = Solution.objects.filter(doubt=doubt).count
            print(doubt.youtube)

    
        return render(request, 'doubts.html', context={'fullname': request.user.get_full_name(),'usertype': userProfile.user_type, 'doubts':doubts, "noteid":noteid})
    else:

        studentprofile = StudentProfile.objects.get(user_profile = userProfile)

        doubts = Doubt.objects.filter(note__id=noteid,student= studentprofile)

        for doubt in doubts:
            doubt.sol_count = Solution.objects.filter(doubt=doubt).count
            print(doubt.youtube)

        return render(request, 'students-doubts.html', context={'fullname': request.user.get_full_name(),'usertype': userProfile.user_type, 'doubts':doubts, "noteid":noteid})

    


    


def addsolution_view(request, noteid, doubtid):
    if request.user.id is None:
        return redirect('login')
    
    userProfile = UserProfile.objects.get(user=request.user)

    if userProfile.user_type == "teacher":
        if request.method == 'POST':
            form = SolutionForm(request.POST, request.FILES)

            if form.is_valid():
                doubt = Doubt.objects.get(id=doubtid)
                form = form.save(commit=False)
                form.doubt = doubt
                form.save()
                print("saved")
                return redirect('doubts',noteid)  # Redirect to the list of notes
        else:
            form = SolutionForm()
            
        return render(request, 'create_solution.html', context={'fullname': request.user.get_full_name(),'usertype': userProfile.user_type, 'form': form})
    
    else:
        return redirect('doubts', noteid)




def solution_view(request, doubtid):

    if request.user.id is None:
        return redirect('login')
    
    userProfile = UserProfile.objects.get(user=request.user)
    if userProfile.user_type == "teacher":
       
        
        solutions = Solution.objects.filter(doubt__id=doubtid).all()
        print(solutions)

    
        return render(request, 'solutions.html', context={'fullname': request.user.get_full_name(),'usertype': userProfile.user_type, 'solutions':solutions, "doubtid":doubtid})
    else:

        solutions = Solution.objects.filter(doubt__id=doubtid).all()
        print(solutions)

    
        return render(request, 'solutions.html', context={'fullname': request.user.get_full_name(),'usertype': userProfile.user_type, 'solutions':solutions, "doubtid":doubtid})






def adddoubt_view(request, noteid):
    if request.user.id is None:
        return redirect('login')
    
    userProfile = UserProfile.objects.get(user=request.user)

    if userProfile.user_type == "student":
        if request.method == 'POST':
            studentProfile = StudentProfile.objects.get(user_profile=userProfile)

            print(studentProfile)
            
            form = DoubtForm(request.POST, request.FILES)
            #print(form)
            if form.is_valid():
                note = Note.objects.get(id=noteid)
                form = form.save(commit=False)
                form.note = note
                form.student = studentProfile
                form.save()
                print("saved")
                return redirect('doubts', noteid)  # Redirect to the list of notes
        else:
        
            form = DoubtForm()
            
        
        return render(request, 'add-doubt.html', context={'fullname': request.user.get_full_name(),'usertype': userProfile.user_type, 'form': form, 'noteid':noteid})
    
    else:
        return redirect('home')
    








def feedback_view(request):
    if request.user.id is None:
        return redirect('login')
    
    userProfile = UserProfile.objects.get(user=request.user)

    if userProfile.user_type == "student":
       
        studentProfile = StudentProfile.objects.get(user_profile=userProfile)
        feedbacks = Feedback.objects.filter(student_profile=studentProfile)

        for feedback in feedbacks:
            feedback.teacher = feedback.teacher_profile.user_profile.user.get_full_name()
    
        return render(request, 'students-feedbacks.html', context={'fullname': request.user.get_full_name(),'usertype': userProfile.user_type, 'feedbacks': feedbacks})
    
    else:
        return redirect('home')
    




def addfeedback_view(request):
    if request.user.id is None:
        return redirect('login')
    
    userProfile = UserProfile.objects.get(user=request.user)

    if userProfile.user_type == "student":
        if request.method == 'POST':
            studentProfile = StudentProfile.objects.get(user_profile=userProfile)

            
            form = FeedbackForm(request.POST)

            
          
            if form.is_valid():
                form = form.save(commit=False)
                form.student_profile = studentProfile
                form.save()
                print("saved")
                return redirect('feedback') 
            else:
                print("not valid")
            
           

        teacher_profiles = TeacherProfile.objects.all()

        for teacher_profile in teacher_profiles:
            teacher_profile.teachername = teacher_profile.user_profile.user.get_full_name()

        form = FeedbackForm()
        
        return render(request, 'add-feedback.html', context={'fullname': request.user.get_full_name(),'usertype': userProfile.user_type, 'form': form, 'teacher_profiles':teacher_profiles})

    else:
        return redirect('home')
    