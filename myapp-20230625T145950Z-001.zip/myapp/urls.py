from django.contrib import admin
from django.urls import path

from . views import login_view, home_view, addnote_view, notes_view, doubts_view, addsolution_view,solution_view, logout_view, adddoubt_view, feedback_view, addfeedback_view



urlpatterns = [
    path('', login_view, name="login"),
    path('home/', home_view, name="home"),
    path('logout/', logout_view, name="logout"),
    path('addnote/<int:subid>', addnote_view, name="addnote"), 
    path('notes/<int:subid>', notes_view, name="notes"),
    path('doubts/<int:noteid>', doubts_view, name="doubts"),
    path('addsolution/<int:noteid>/<int:doubtid>', addsolution_view, name="addsolution"),
    path('solutions/<int:doubtid>', solution_view, name="solutions"),
    path('adddoubt/<int:noteid>', adddoubt_view, name="adddoubt"), 
    path('feedback/', feedback_view, name="feedback"),
    path('addfeedback/', addfeedback_view, name="addfeedback")
]