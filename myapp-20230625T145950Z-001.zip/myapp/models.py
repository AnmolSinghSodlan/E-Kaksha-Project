from django.contrib.auth.models import User
from django.db import models
import uuid

from django.core.validators import MinValueValidator, MaxValueValidator


class UserProfile(models.Model):
    USER_TYPE_CHOICES = (
        ('teacher', 'Teacher'),
        ('student', 'Student'),
    )

    id = models.AutoField(primary_key=True)
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    user_type = models.CharField(max_length=20, choices=USER_TYPE_CHOICES)
    
    def __str__(self) :
        return self.user.username +" ("+self.user_type+")"


class TeacherProfile(models.Model):
    id = models.AutoField(primary_key=True)
    user_profile = models.OneToOneField(UserProfile, on_delete=models.CASCADE)
        
    def __str__(self) :
        return self.user_profile.user.username +" ("+self.user_profile.user_type+")"


class Subject(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    description = models.TextField()
    teacher = models.ForeignKey('TeacherProfile', on_delete=models.CASCADE)
    
    # Add any additional fields or methods as needed
    
    def __str__(self):
        return self.name + "( teacher is: "+self.teacher.user_profile.user.username+")"
    

class Note(models.Model):
    id = models.AutoField(primary_key=True)
    subject = models.ForeignKey('Subject', on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    description = models.TextField()
    content = models.TextField()
    youtube = models.URLField(blank=True)
    file = models.FileField(upload_to='pdf_files/', blank=True)
    
    # Add any additional fields or methods as needed

    def __str__(self):
        return self.title +"(subject is: "+ self.subject.name + ")"




class Doubt(models.Model):
    id = models.AutoField(primary_key=True)
    note = models.ForeignKey(Note, on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    student =  models.ForeignKey('StudentProfile', on_delete=models.CASCADE)
    description = models.TextField()
    content = models.TextField()
    youtube = models.URLField(blank=True)
    file = models.FileField(upload_to='doubt_files/', blank=True)

    def __str__(self):
        return self.title + "note"+ self.title + "(subject is: "+ self.note.subject.name + ")"
    



class Solution(models.Model):
    id = models.AutoField(primary_key=True)
    doubt = models.ForeignKey(Doubt, on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    description = models.TextField()
    content = models.TextField()
    youtube = models.URLField(blank=True)
    file = models.FileField(upload_to='solution_files/', blank=True)

    def __str__(self):
        return self.title + "note"+ self.title + " (note is "+ self.doubt.note.title +" subject is: "+ self.doubt.note.subject.name + ")"
    




class StudentProfile(models.Model):
    id = models.AutoField(primary_key=True)
    user_profile = models.OneToOneField(UserProfile, on_delete=models.CASCADE)
    subjects = models.ManyToManyField(Subject)
    branch = models.CharField(max_length=255)
    semester = models.PositiveIntegerField()
    roll_number = models.CharField(max_length=255)



    def __str__(self) :
        return "["+self.roll_number + "]" +self.user_profile.user.username +" ("+self.user_profile.user_type+")"
    




class Feedback(models.Model):
    id = models.AutoField(primary_key=True)
    teacher_profile = models.ForeignKey(TeacherProfile, on_delete=models.CASCADE)
    student_profile = models.ForeignKey(StudentProfile, on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    description = models.TextField()
    rating = models.PositiveIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])

    # Add any additional fields or methods as needed

    def __str__(self):
        return self.title